package org.cap.onetoone;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Customer {

	@Id
	private int customerId;
	private String customerName;
	private LocalDate regDate;
	
	public Customer() {
		
	}
	
	public Customer(int customerId, String customerName, LocalDate regDate) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.regDate = regDate;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public LocalDate getRegDate() {
		return regDate;
	}
	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", regDate=" + regDate + "]";
	}
	
}
