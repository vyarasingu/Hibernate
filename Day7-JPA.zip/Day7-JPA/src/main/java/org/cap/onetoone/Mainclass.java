package org.cap.onetoone;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Mainclass {

	public static void main(String[] args) {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager= emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
			Customer customer=new Customer(123, "Tom", LocalDate.now());
			Address address=new Address();
			address.setAddressId(1001);
			address.setAddressLine("North Avennue");
			address.setCity("Chennai");
			address.setCustomer(customer);
			
			entityManager.persist(customer);
			entityManager.persist(address);
		
		
		transaction.commit();

	}

}
